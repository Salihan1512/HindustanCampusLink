from flask import Flask, render_template, request, redirect, url_for, session
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from flask_socketio import SocketIO, join_room, leave_room, send

app = Flask(__name__)
app.secret_key = 'your_secret_key'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)
socketio = SocketIO(app)

# User model
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), nullable=False)
    department = db.Column(db.String(50), nullable=False)
    batch = db.Column(db.String(50), nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)
    password = db.Column(db.String(100), nullable=False)

# Routes
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        user = User.query.filter_by(email=email, password=password).first()
        if user:
            session['user_id'] = user.id
            session['name'] = user.name
            session['department'] = user.department
            session['batch'] = user.batch
            return redirect(url_for('chat'))
        else:
            return "Login failed"
    return render_template('login.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        name = request.form['name']
        department = request.form['department']
        batch = request.form['batch']
        email = request.form['email']
        password = request.form['password']

        user = User(name=name, department=department, batch=batch, email=email, password=password)
        db.session.add(user)
        db.session.commit()
        return redirect(url_for('login'))

    return render_template('index.html')

@app.route('/chat')
def chat():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    return render_template('chat.html', name=session['name'])

@socketio.on('join')
def on_join(data):
    name = session['name']
    department = session['department']
    batch = session['batch']
    
    join_room('college')
    join_room(department)
    join_room(f'{department}-{batch}')
    
    send(f'{name} has joined the college chat!', to='college')
    send(f'{name} has joined the department chat!', to=department)
    send(f'{name} has joined the batch chat!', to=f'{department}-{batch}')

@socketio.on('message')
def handle_message(data):
    room = data['room']
    send({'msg': data['msg'], 'name': session['name']}, to=room)

if __name__ == '__main__':
    db.create_all()
    socketio.run(app, debug=True)
