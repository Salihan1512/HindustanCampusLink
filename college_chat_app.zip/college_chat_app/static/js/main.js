document.addEventListener('DOMContentLoaded', function () {
    const socket = io.connect('http://' + document.domain + ':' + location.port);

    // Join the chat rooms
    socket.emit('join', {});

    // Listen for incoming messages and display them
    socket.on('message', function (data) {
        const chatBox = document.getElementById('chat-box');
        chatBox.innerHTML += `<p><strong>${data.name}:</strong> ${data.msg}</p>`;
        chatBox.scrollTop = chatBox.scrollHeight; // Auto scroll to the bottom
    });

    // Handle message form submission
    document.getElementById('message-form').addEventListener('submit', function (e) {
        e.preventDefault();
        
        const messageInput = document.getElementById('message');
        const message = messageInput.value.trim();
        const chatType = document.getElementById('chat-type').value;
        
        if (message === '') return;

        let room;
        if (chatType === 'college') {
            room = 'college';
        } else if (chatType === 'department') {
            room = department;
        } else if (chatType === 'batch') {
            room = `${department}-${batch}`;
        }

        // Send the message to the selected chat room
        socket.emit('message', { room: room, msg: message });
        
        // Clear the message input field
        messageInput.value = '';
    });
});